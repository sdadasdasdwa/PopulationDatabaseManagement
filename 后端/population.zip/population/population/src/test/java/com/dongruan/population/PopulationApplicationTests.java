package com.dongruan.population;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PopulationApplicationTests {

	@Test
	void contextLoads() {
	}

}
